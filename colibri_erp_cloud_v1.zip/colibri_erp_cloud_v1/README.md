# Colibrí ERP Cloud

ERP Cloud para Brasería El Colibrí.

## Accesos

- Gestión: `https://manager.braseria-elcolibri.es`
- Fichajes empleados: `https://fichar.braseria-elcolibri.es`
- También funciona `/fichar` dentro del mismo dominio.

## Módulos incluidos en esta versión

- Dashboard de gestión.
- Cuadrantes semanales con hasta 3 empleados por casilla.
- Fichajes online con PIN y GPS obligatorio.
- Panel de fichajes en tiempo real.
- Exportación CSV de fichajes.
- Comparador de horas declaradas por WhatsApp.
- Plantilla semanal para empleados.
- PDF / impresión del cuadrante.
- Diseño corporativo con logo final sin eslogan.

## Supabase

La app usa la base de datos Supabase ya configurada del proyecto `xccyaoziutlxxklcofrw`.

Si todavía no has creado la función avanzada con GPS, ejecuta `supabase_gps_upgrade.sql` en Supabase SQL Editor.

## Clave de administrador temporal

`131313`

> Recomendación: cambiarla más adelante por autenticación real de Supabase.
