-- Mejora opcional para guardar GPS en columnas separadas.
-- Ejecutar en Supabase > SQL Editor.

alter table time_clock add column if not exists latitude double precision;
alter table time_clock add column if not exists longitude double precision;
alter table time_clock add column if not exists accuracy_m integer;

create or replace function registrar_fichaje(
  p_employee_name text,
  p_pin text,
  p_type text,
  p_note text default null,
  p_latitude double precision default null,
  p_longitude double precision default null,
  p_accuracy_m integer default null
)
returns json
language plpgsql
security definer
as $$
declare
  v_employee employees%rowtype;
  v_last_type text;
begin
  select * into v_employee
  from employees
  where name = p_employee_name
    and active = true
    and can_clock = true;

  if not found then
    return json_build_object('ok', false, 'message', 'Empleado no autorizado');
  end if;

  if v_employee.pin is distinct from p_pin then
    return json_build_object('ok', false, 'message', 'PIN incorrecto');
  end if;

  if p_type not in ('entrada','salida') then
    return json_build_object('ok', false, 'message', 'Tipo de fichaje no válido');
  end if;

  select type into v_last_type
  from time_clock
  where employee_name = p_employee_name
  order by created_at desc
  limit 1;

  if v_last_type = p_type then
    return json_build_object('ok', false, 'message', 'Ya existe un último fichaje de tipo ' || p_type);
  end if;

  insert into time_clock (employee_name, type, note, latitude, longitude, accuracy_m)
  values (p_employee_name, p_type, p_note, p_latitude, p_longitude, p_accuracy_m);

  return json_build_object(
    'ok', true,
    'message', 'Fichaje registrado correctamente',
    'employee', p_employee_name,
    'type', p_type,
    'time', now(),
    'latitude', p_latitude,
    'longitude', p_longitude,
    'accuracy_m', p_accuracy_m
  );
end;
$$;
