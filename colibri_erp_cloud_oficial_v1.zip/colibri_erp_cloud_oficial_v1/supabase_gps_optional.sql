-- Opcional: añade campos GPS a la tabla de fichajes si quieres guardarlos separados.
-- La app ya funciona guardando el GPS dentro de note.
alter table time_clock add column if not exists latitude double precision;
alter table time_clock add column if not exists longitude double precision;
alter table time_clock add column if not exists accuracy_m double precision;
alter table time_clock add column if not exists distance_m double precision;
