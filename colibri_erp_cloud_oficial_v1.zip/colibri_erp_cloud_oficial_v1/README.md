# Colibrí ERP Cloud - Oficial v1.0

ERP Cloud para Brasería El Colibrí.

## Accesos

- Gestión: `https://manager.braseria-elcolibri.es`
- Fichajes empleados: `https://fichar.braseria-elcolibri.es`

## Clave de administrador

`131313`

## Base de datos

Conectado a Supabase con la tabla `time_clock` y la función RPC `registrar_fichaje`.

## Publicación

Sube estos archivos al repositorio GitHub `colibri-manager-pro`. Vercel desplegará automáticamente.
